final List<Map<String, String>> album = const [
    {
      'imagem':
          "https://images.pexels.com/photos/213781/pexels-photo-213781.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
      'tituloAppBar': "Foto 1",
      'titulo': "Primeira Foto",
      'descricao':
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in tempus ante, vitae viverra mauris. Pellentesque maximus nisl eros, sit amet pharetra est laoreet at. Vivamus a malesuada ipsum. Cras ligula arcu, porta ut lectus sit amet, finibus ultricies lorem. Nam venenatis lectus semper turpis aliquam, at malesuada mauris suscipit. In eget urna vestibulum, suscipit nulla ut, vestibulum lorem. Nulla hendrerit arcu odio, eu mattis neque commodo et. Nunc et felis ac dolor tincidunt gravida quis sed felis. Aenean at diam a massa tristique dictum et eget augue. Sed viverra ultrices diam, ac convallis magna feugiat nec. Integer faucibus feugiat purus, nec venenatis sapien efficitur ac."
    },
    {
      'imagem':
          "https://images.pexels.com/photos/213782/pexels-photo-213782.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
      'tituloAppBar': "Foto 2",
      'titulo': "Segunda foto",
      'descricao':
          "Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nam lobortis blandit fermentum. Sed eget dui porta, efficitur erat sit amet, cursus mauris. Mauris consectetur elementum luctus. Nam orci libero, tincidunt id quam sit amet, tristique ultrices urna. Praesent tempor, diam et tristique dapibus, dolor tellus fermentum urna, vestibulum elementum velit neque et purus. Ut viverra purus posuere leo venenatis, id scelerisque nunc gravida. Aliquam eu tortor hendrerit, pretium ipsum sed, tincidunt augue. In non dui ac ante aliquam dictum eu eu arcu. Ut laoreet sit amet purus et ornare. Aenean porta nisl finibus neque feugiat rhoncus. Ut lobortis risus et feugiat semper. Nulla eget massa ac felis varius pharetra et ac quam. Sed suscipit velit pretium, malesuada turpis eget, convallis erat. Pellentesque nec nulla eu felis mollis sodales sit amet non tortor. Vivamus accumsan porta magna in sollicitudin."
    },
    {
      'imagem':
          "https://images.pexels.com/photos/213783/pexels-photo-213783.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
      'tituloAppBar': "Foto 3",
      'titulo': "Terceira foto",
      'descricao':
          "Integer aliquam arcu vitae metus mollis dignissim. Aliquam vitae ante egestas, feugiat enim porttitor, tempor mauris. Praesent porta convallis maximus. Aliquam erat volutpat. Pellentesque suscipit odio nisl, nec rutrum leo pretium non. Vestibulum accumsan erat libero, at sagittis erat tempus a. Morbi suscipit feugiat turpis, quis mollis diam. Nunc bibendum erat et orci imperdiet, ac tristique lectus hendrerit. Donec efficitur augue vel arcu ornare faucibus. Sed in odio et libero volutpat dictum a nec libero. Nam ornare placerat orci vitae pretium. Nunc lorem metus, gravida et lectus nec, euismod efficitur nibh. Nulla quis commodo eros. Aenean non eros et mauris dapibus blandit quis nec odio. Vivamus bibendum congue cursus. Praesent eget tempor mi."
    },
    {
      'imagem':
          "https://images.pexels.com/photos/213784/pexels-photo-213784.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
      'tituloAppBar': "Foto 4",
      'titulo': "Quarta foto",
      'descricao':
          "Morbi magna risus, consectetur vitae vehicula vel, dictum sit amet dolor. Nunc justo libero, dictum et suscipit quis, fermentum ac enim. Nullam faucibus ultricies purus eget scelerisque. Integer id leo id orci dignissim maximus. Mauris varius fringilla quam at molestie. Vivamus sagittis lobortis semper. Duis ac blandit velit."
    },
    {
      'imagem':
          "https://images.pexels.com/photos/213785/pexels-photo-213785.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
      'tituloAppBar': "Foto 5",
      'titulo': "Quinta foto",
      'descricao':
          "Morbi eu sem justo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nunc lacinia suscipit mauris ut porta. Nunc posuere diam id libero euismod sagittis. Duis dignissim eget elit id rhoncus. Nam at semper nibh. Morbi risus diam, auctor feugiat ultrices vel, porttitor eget risus. Integer finibus purus a suscipit commodo. Vestibulum massa lorem, viverra a ex eget, pharetra placerat augue. Maecenas rhoncus elementum sem, nec dignissim orci commodo eu. Etiam non suscipit tellus."
    },
    {
      'imagem':
          "https://images.pexels.com/photos/213786/pexels-photo-213786.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
      'tituloAppBar': "Foto 6",
      'titulo': "Sexta foto",
      'descricao':
          "Cras orci libero, fermentum non lacus sed, porta feugiat diam. Mauris pharetra interdum metus. Vestibulum aliquet, arcu sed consequat pretium, magna lectus aliquam elit, ut eleifend lorem arcu vulputate enim. Donec aliquam at urna et accumsan. Duis finibus, urna sit amet mattis fringilla, mi leo venenatis lacus, rutrum ullamcorper ante sem nec neque. Sed auctor turpis sit amet lorem posuere lobortis. Quisque suscipit justo eu orci interdum, a maximus sem dapibus. Duis laoreet iaculis orci, non eleifend leo iaculis eget. Sed ornare porta sapien, a consequat nunc euismod non."
    },
    {
      'imagem':
          "https://images.pexels.com/photos/213787/pexels-photo-213787.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
      'tituloAppBar': "Foto 7",
      'titulo': "Setima foto",
      'descricao':
          "Quisque faucibus diam at enim euismod, sit amet commodo lectus consectetur. Duis auctor dapibus pharetra. Praesent in finibus mi. Sed tristique turpis ex, sit amet auctor diam aliquet vel. Aliquam aliquet, lectus nec rhoncus consequat, arcu felis ultrices augue, at scelerisque diam odio in tortor. Etiam luctus magna et ipsum elementum malesuada. Nulla ut ultricies quam, at eleifend nibh. Sed cursus libero eget dolor sollicitudin tempus. Phasellus fermentum ligula et justo molestie, at luctus metus cursus. Nam maximus erat eu odio auctor, molestie rutrum urna ullamcorper. Suspendisse potenti. Quisque eu risus urna. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae;"
    },
    {
      'imagem':
          "https://images.pexels.com/photos/213788/pexels-photo-213788.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
      'tituloAppBar': "Foto 8",
      'titulo': "Oitava foto",
      'descricao':
          "Integer ut feugiat eros. Vivamus blandit odio nec elementum ultricies. Fusce consectetur turpis libero, eget maximus leo efficitur at. Integer dapibus efficitur consectetur. In lectus dui, lacinia a eros posuere, dignissim posuere tellus. Quisque id tincidunt velit, quis faucibus neque. Donec interdum libero nulla, et lacinia nunc lobortis ac."
    },
    {
      'imagem':
          "https://images.pexels.com/photos/213789/pexels-photo-213789.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
      'tituloAppBar': "Foto 9",
      'titulo': "Nona foto",
      'descricao':
          "Donec eros ipsum, facilisis vel pellentesque ac, lobortis a nisl. Praesent tempus lectus quis nulla ultricies tempus. Duis egestas erat eget enim vulputate fermentum sed nec turpis. Donec sodales elit a venenatis feugiat. Fusce ac urna in libero faucibus finibus at in odio. Quisque vitae nunc nisi. Nullam sed nibh at erat aliquam gravida. Fusce condimentum vitae ante id eleifend. Praesent auctor rutrum suscipit. Nunc in ex non metus ultricies elementum. Duis viverra semper est, eget auctor dolor. Etiam pretium quis sem sed lacinia."
    },
  ];