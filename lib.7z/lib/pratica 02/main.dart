import 'package:flutter/material.dart';

void main() {
  runApp(
    Text(
      'Matheus de Mello Vieira',
      textDirection: TextDirection.ltr,
    ), //Text.
  ); //runApp.
}
