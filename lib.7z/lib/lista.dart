const List<Map<String, Object>> telasInfo = [
  {
    "appTitle": "Primeira Tela",
    "numero": "1",
    "anterior": -1,
    "proximo": 1,
    "rota": ""
  },
  {
    "appTitle": "Segunda Tela",
    "numero": "2",
    "anterior": 0,
    "proximo": 2,
    "rota": "segunda"
  },
  {
    "appTitle": "Terceira Tela",
    "numero": "3",
    "anterior": 1,
    "proximo": 3,
    "rota": "terceira"
  },
  {
    "appTitle": "Quarta Tela",
    "numero": "4",
    "anterior": 2,
    "proximo": 1,
    "rota": "quarta"
  }
];

